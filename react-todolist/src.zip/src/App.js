import logo from './logo.svg';
import './App.css';
import TodoList from './Components/todoList';

function App() {
  return (
    <div className="App">
      <TodoList />
    </div>
  );
}

export default App;
